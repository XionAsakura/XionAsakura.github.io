# CS 499 Milestone Two - Software Design and Engineering

## Contents

- `Original/textbasedgame_original.py` contains the original IT 140 artifact.
- `Enhanced/textbasedgame_enhanced.py` contains the software design and engineering enhancement.

## Main Improvements

- Replaced global mutable game state with `Player` and `Game` classes.
- Separated command parsing, movement, item pickup, room events, and final encounter logic.
- Added normalized, case-insensitive command handling.
- Added shorter command options such as `north` and `take Hammer`.
- Replaced recursive restart behavior with a controlled replay loop.
- Separated Ganon from collectible room items by using a dedicated encounter field.
- Improved validation and user feedback.
- Added type hints, docstrings, constants, and a standard Python entry point.
- Preserved the Zelda story, locations, required items, and Cucco Easter egg.

## Running the Enhanced Game

```bash
python textbasedgame_enhanced.py
```
