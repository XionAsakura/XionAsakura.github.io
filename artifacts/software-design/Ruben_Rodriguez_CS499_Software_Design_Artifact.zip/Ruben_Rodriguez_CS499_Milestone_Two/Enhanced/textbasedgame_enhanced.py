"""Enhanced IT 140 text-based adventure game.

This version refactors the original project into one organized file using
object-oriented design, clearer state management, normalized commands,
and a controlled replay loop.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

STARTING_ROOM = "Kokiri Forest"
FINAL_ROOM = "Top of Hyrule Castle"
FINAL_ENCOUNTER = "Ganon"

DIRECTIONS = {"north", "south", "east", "west"}

REQUIRED_ITEMS = {
    "Triforce of Wisdom",
    "Triforce of Courage",
    "Triforce of Power",
    "Hammer",
    "Hylian Shield",
    "Master Sword",
}


def build_world() -> Dict[str, Dict[str, str]]:
    """Return a fresh copy of the room map for a new game session."""
    return {
        "Kokiri Forest": {
            "south": "Lost Woods",
            "north": "Hyrule Field",
            "east": "Gerudo Valley",
            "west": "Lake Hylia",
        },
        "Lake Hylia": {
            "north": "Temple of Wisdom",
            "east": "Kokiri Forest",
        },
        "Temple of Wisdom": {
            "south": "Lake Hylia",
            "item": "Triforce of Wisdom",
        },
        "Lost Woods": {
            "north": "Kokiri Forest",
            "south": "Temple of Courage",
        },
        "Temple of Courage": {
            "north": "Lost Woods",
            "item": "Triforce of Courage",
        },
        "Gerudo Valley": {
            "west": "Kokiri Forest",
            "east": "Temple of Power",
        },
        "Temple of Power": {
            "west": "Gerudo Valley",
            "item": "Triforce of Power",
        },
        "Hyrule Field": {
            "south": "Kokiri Forest",
            "east": "Death Valley",
            "north": "Hyrule Castle",
        },
        "Death Valley": {
            "west": "Hyrule Field",
            "item": "Hammer",
        },
        "Hyrule Castle": {
            "south": "Hyrule Field",
            "north": FINAL_ROOM,
            "east": "Castle Basement",
            "west": "Kitchen",
            "item": "Hylian Shield",
        },
        "Kitchen": {
            "east": "Hyrule Castle",
            "event": "cucco",
        },
        "Castle Basement": {
            "west": "Hyrule Castle",
            "item": "Master Sword",
        },
        FINAL_ROOM: {
            "south": "Hyrule Castle",
            "encounter": FINAL_ENCOUNTER,
        },
    }


@dataclass
class Player:
    """Track the player's current location and collected items."""

    current_room: str = STARTING_ROOM
    inventory: List[str] = field(default_factory=list)

    def has_all_required_items(self) -> bool:
        """Return True when the player has every required item."""
        return REQUIRED_ITEMS.issubset(set(self.inventory))


class Game:
    """Manage the game world, commands, and overall session state."""

    def __init__(self) -> None:
        self.rooms = build_world()
        self.player = Player()
        self.is_running = True

    def show_intro(self) -> None:
        """Display the opening story and supported commands."""
        print("Link wakes up from his bed in Kokiri Forest.")
        print('On his table he sees "HELP!" with a picture of Zelda being held by Ganon.')
        print("Save Zelda, Link!")
        print()
        print("Commands:")
        print("  go <direction>     Example: go north")
        print("  north/south/east/west")
        print("  pick up <item>     Example: pick up Master Sword")
        print("  take <item>        Example: take Hammer")
        print("  inventory")
        print("  help")
        print("  exit")
        print()

    def display_status(self) -> None:
        """Display the player's current location, inventory, and room details."""
        room = self.rooms[self.player.current_room]
        available_directions = [direction.title() for direction in DIRECTIONS if direction in room]

        print("-----------------")
        print(f"Current Room: {self.player.current_room}")
        print("Available Directions:", ", ".join(sorted(available_directions)) or "None")

        item = room.get("item")
        if item:
            print(f"Item: {item}")
        else:
            print("There appears to be no item here.")

        print(
            "Inventory:",
            ", ".join(self.player.inventory) if self.player.inventory else "Empty",
        )
        print("-----------------")

    @staticmethod
    def normalize_command(raw_command: str) -> str:
        """Trim repeated whitespace and convert command keywords to lowercase."""
        return " ".join(raw_command.strip().split())

    @staticmethod
    def parse_command(command: str) -> Tuple[str, Optional[str]]:
        """Convert user input into an action and optional argument."""
        lowered = command.lower()

        if lowered in DIRECTIONS:
            return "move", lowered

        if lowered.startswith("go "):
            return "move", lowered[3:].strip()

        if lowered.startswith("pick up "):
            return "pickup", command[8:].strip()

        if lowered.startswith("take "):
            return "pickup", command[5:].strip()

        if lowered in {"inventory", "inv"}:
            return "inventory", None

        if lowered in {"help", "commands"}:
            return "help", None

        if lowered in {"exit", "quit"}:
            return "exit", None

        return "invalid", None

    def move_player(self, direction: str) -> None:
        """Move the player when the requested exit exists."""
        if direction not in DIRECTIONS:
            print("That is not a valid direction.")
            return

        current_room_data = self.rooms[self.player.current_room]
        destination = current_room_data.get(direction)

        if destination is None:
            print("An invisible wall blocks your way. Try another direction.")
            return

        self.player.current_room = destination
        self.handle_room_event()

    def pick_up_item(self, requested_item: str) -> None:
        """Collect the current room's item when the requested name matches."""
        if not requested_item:
            print("Tell me which item you want to pick up.")
            return

        room = self.rooms[self.player.current_room]
        room_item = room.get("item")

        if room_item is None:
            print("There is no item here to pick up.")
            return

        if requested_item.casefold() != room_item.casefold():
            print(f"There is no {requested_item} here to pick up.")
            return

        self.player.inventory.append(room_item)
        del room["item"]
        print(f"{room_item} has been added to your inventory.")

        missing_items = REQUIRED_ITEMS.difference(self.player.inventory)
        if not missing_items:
            print("You are now ready to face Ganon! Head to the top of Hyrule Castle.")

    def handle_room_event(self) -> None:
        """Handle special room events after movement."""
        room = self.rooms[self.player.current_room]

        if room.get("event") == "cucco":
            print("A single Cucco stands before you, menacingly...")
            print("There is nowhere else to go but back where you came from.")

        if room.get("encounter") == FINAL_ENCOUNTER:
            self.resolve_final_encounter()

    def resolve_final_encounter(self) -> None:
        """End the session with the appropriate Ganon result."""
        if self.player.has_all_required_items():
            print()
            print("You have everything you need. Ganon appears before you at the top of Hyrule Castle.")
            print("After an intense fight, Link defeats Ganon.")
            print("Link has saved Zelda and the land of Hyrule.")
        else:
            missing_count = len(REQUIRED_ITEMS.difference(self.player.inventory))
            print()
            print("You enter the top of Hyrule Castle and feel a sinister force.")
            print(f"You are still missing {missing_count} required item(s).")
            print("Before you can escape, Ganon strikes. It appears this is the end of our hero.")

        self.is_running = False

    def show_help(self) -> None:
        """Display the accepted command formats."""
        print("Use 'go north' or simply 'north' to move.")
        print("Use 'pick up <item>' or 'take <item>' to collect an item.")
        print("Use 'inventory' to review collected items.")
        print("Use 'exit' to leave the game.")

    def confirm_exit(self) -> bool:
        """Return True only when the player confirms leaving the game."""
        while True:
            response = input("Would you like to leave? (yes or no): ").strip().lower()
            if response in {"yes", "y"}:
                return True
            if response in {"no", "n"}:
                return False
            print("Please enter yes or no.")

    def process_command(self, raw_command: str) -> None:
        """Route a command to the appropriate gameplay method."""
        command = self.normalize_command(raw_command)
        action, argument = self.parse_command(command)

        if action == "move" and argument is not None:
            self.move_player(argument)
        elif action == "pickup" and argument is not None:
            self.pick_up_item(argument)
        elif action == "inventory":
            print(
                "Inventory:",
                ", ".join(self.player.inventory) if self.player.inventory else "Empty",
            )
        elif action == "help":
            self.show_help()
        elif action == "exit":
            if self.confirm_exit():
                print("You have exited the game.")
                self.is_running = False
        else:
            print("Invalid command. Type 'help' to see the available commands.")

    def run(self) -> None:
        """Run one complete game session."""
        self.show_intro()

        while self.is_running:
            self.display_status()
            command = input("Enter a command: ")
            self.process_command(command)


def ask_to_play_again() -> bool:
    """Return True when the player wants to start a new session."""
    while True:
        response = input("Would you like to play again? (yes or no): ").strip().lower()
        if response in {"yes", "y"}:
            return True
        if response in {"no", "n"}:
            return False
        print("Please enter yes or no.")


def main() -> None:
    """Run game sessions without recursive restarts."""
    while True:
        game = Game()
        game.run()

        if not ask_to_play_again():
            print("Thank you for playing.")
            break


if __name__ == "__main__":
    main()
