\
"""Automated tests for the CS 499 Milestone Three game enhancement."""

import unittest

from textbasedgame_algorithms_enhanced import (
    FINAL_ROOM,
    Game,
    REQUIRED_ITEMS,
    STARTING_ROOM,
    build_world,
    validate_world,
)


class WorldValidationTests(unittest.TestCase):
    def test_original_world_is_valid(self) -> None:
        validate_world(build_world())

    def test_unknown_room_connection_is_rejected(self) -> None:
        rooms = build_world()
        rooms[STARTING_ROOM]["north"] = "Missing Room"

        with self.assertRaisesRegex(ValueError, "unknown room"):
            validate_world(rooms)

    def test_missing_required_item_is_rejected(self) -> None:
        rooms = build_world()
        del rooms["Death Valley"]["item"]

        with self.assertRaisesRegex(ValueError, "Required item is missing: Hammer"):
            validate_world(rooms)


class BreadthFirstSearchTests(unittest.TestCase):
    def setUp(self) -> None:
        self.game = Game()

    def test_shortest_path_to_temple_of_wisdom(self) -> None:
        result = self.game.find_shortest_path(
            STARTING_ROOM, {"Temple of Wisdom"}
        )
        self.assertEqual((['west', 'north'], 'Temple of Wisdom'), result)

    def test_search_returns_none_for_unreachable_target(self) -> None:
        self.game.rooms["Lake Hylia"].pop("north")
        result = self.game.find_shortest_path(
            STARTING_ROOM, {"Temple of Wisdom"}
        )
        self.assertIsNone(result)

    def test_search_is_deterministic_for_equal_distance_targets(self) -> None:
        result = self.game.find_shortest_path(
            STARTING_ROOM, {"Hyrule Castle", "Temple of Power"}
        )
        self.assertEqual((['north', 'north'], 'Hyrule Castle'), result)


class HintAndInventoryTests(unittest.TestCase):
    def setUp(self) -> None:
        self.game = Game()

    def test_hint_points_to_nearest_missing_item(self) -> None:
        self.assertEqual(
            "Hint: Go north toward the Hylian Shield. It is 2 rooms away.",
            self.game.get_hint(),
        )

    def test_hint_tells_player_to_collect_current_item(self) -> None:
        self.game.player.current_room = "Temple of Wisdom"
        self.assertEqual(
            "Hint: Pick up the Triforce of Wisdom in this room.",
            self.game.get_hint(),
        )

    def test_hint_points_to_ganon_after_all_items_are_collected(self) -> None:
        self.game.player.inventory.update(REQUIRED_ITEMS)
        self.assertEqual(
            "Hint: Go north toward Ganon at the top of Hyrule Castle. He is 3 rooms away.",
            self.game.get_hint(),
        )

    def test_set_inventory_prevents_duplicates(self) -> None:
        self.game.player.inventory.add("Hammer")
        self.game.player.inventory.add("Hammer")
        self.assertEqual(1, len(self.game.player.inventory))

    def test_hint_command_is_recognized(self) -> None:
        self.assertEqual(("hint", None), self.game.parse_command("hint"))


class GameplayCompatibilityTests(unittest.TestCase):
    def test_game_keeps_milestone_two_design_structure(self) -> None:
        game = Game()
        self.assertTrue(hasattr(game, "player"))
        self.assertTrue(hasattr(game, "rooms"))
        self.assertEqual(STARTING_ROOM, game.player.current_room)

    def test_all_required_items_can_be_collected_as_unique_values(self) -> None:
        game = Game()
        game.player.inventory.update(REQUIRED_ITEMS)
        self.assertTrue(game.player.has_all_required_items())
        self.assertEqual(len(REQUIRED_ITEMS), len(game.player.inventory))

    def test_final_room_remains_the_ganon_encounter(self) -> None:
        game = Game()
        self.assertEqual("Ganon", game.rooms[FINAL_ROOM]["encounter"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
