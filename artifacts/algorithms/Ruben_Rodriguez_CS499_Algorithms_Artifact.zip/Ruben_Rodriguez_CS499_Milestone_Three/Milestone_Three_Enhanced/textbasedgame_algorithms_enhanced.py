\
"""Algorithms and data structures enhancement for the IT 140 adventure game.

Ruben Rodriguez
CS 499 Milestone Three

This version builds on the Milestone Two software design refactor. It keeps the
Player and Game classes while adding graph validation, set-based inventory
management, and a breadth-first search hint system.
"""

from __future__ import annotations

from collections import Counter, deque
from dataclasses import dataclass, field
from typing import Dict, Iterable, Optional, Set, Tuple

STARTING_ROOM = "Kokiri Forest"
FINAL_ROOM = "Top of Hyrule Castle"
FINAL_ENCOUNTER = "Ganon"

# A fixed direction order makes breadth-first search results predictable when
# two goals are the same number of rooms away.
DIRECTION_ORDER = ("north", "east", "south", "west")
DIRECTIONS = frozenset(DIRECTION_ORDER)

REQUIRED_ITEM_ORDER = (
    "Triforce of Wisdom",
    "Triforce of Courage",
    "Triforce of Power",
    "Hammer",
    "Hylian Shield",
    "Master Sword",
)
REQUIRED_ITEMS = frozenset(REQUIRED_ITEM_ORDER)

RoomData = Dict[str, str]
WorldMap = Dict[str, RoomData]


def build_world() -> WorldMap:
    """Return a fresh room graph for a new game session."""
    return {
        "Kokiri Forest": {
            "south": "Lost Woods",
            "north": "Hyrule Field",
            "east": "Gerudo Valley",
            "west": "Lake Hylia",
        },
        "Lake Hylia": {
            "north": "Temple of Wisdom",
            "east": "Kokiri Forest",
        },
        "Temple of Wisdom": {
            "south": "Lake Hylia",
            "item": "Triforce of Wisdom",
        },
        "Lost Woods": {
            "north": "Kokiri Forest",
            "south": "Temple of Courage",
        },
        "Temple of Courage": {
            "north": "Lost Woods",
            "item": "Triforce of Courage",
        },
        "Gerudo Valley": {
            "west": "Kokiri Forest",
            "east": "Temple of Power",
        },
        "Temple of Power": {
            "west": "Gerudo Valley",
            "item": "Triforce of Power",
        },
        "Hyrule Field": {
            "south": "Kokiri Forest",
            "east": "Death Valley",
            "north": "Hyrule Castle",
        },
        "Death Valley": {
            "west": "Hyrule Field",
            "item": "Hammer",
        },
        "Hyrule Castle": {
            "south": "Hyrule Field",
            "north": FINAL_ROOM,
            "east": "Castle Basement",
            "west": "Kitchen",
            "item": "Hylian Shield",
        },
        "Kitchen": {
            "east": "Hyrule Castle",
            "event": "cucco",
        },
        "Castle Basement": {
            "west": "Hyrule Castle",
            "item": "Master Sword",
        },
        FINAL_ROOM: {
            "south": "Hyrule Castle",
            "encounter": FINAL_ENCOUNTER,
        },
    }


def reachable_rooms(rooms: WorldMap, start_room: str) -> Set[str]:
    """Return every room reachable from start_room using breadth-first search."""
    if start_room not in rooms:
        return set()

    queue = deque([start_room])
    visited = {start_room}

    while queue:
        room_name = queue.popleft()
        room = rooms[room_name]

        for direction in DIRECTION_ORDER:
            destination = room.get(direction)
            if destination in rooms and destination not in visited:
                visited.add(destination)
                queue.append(destination)

    return visited


def validate_world(rooms: WorldMap) -> None:
    """Raise ValueError when the room graph contains structural problems."""
    errors = []

    if STARTING_ROOM not in rooms:
        errors.append(f"Missing starting room: {STARTING_ROOM}")
    if FINAL_ROOM not in rooms:
        errors.append(f"Missing final room: {FINAL_ROOM}")

    item_counts: Counter[str] = Counter()

    for room_name, room in rooms.items():
        for direction in DIRECTION_ORDER:
            destination = room.get(direction)
            if destination is not None and destination not in rooms:
                errors.append(
                    f"{room_name} points {direction} to unknown room {destination}."
                )

        item = room.get("item")
        if item is not None:
            item_counts[item] += 1

    for required_item in REQUIRED_ITEM_ORDER:
        count = item_counts[required_item]
        if count == 0:
            errors.append(f"Required item is missing: {required_item}")
        elif count > 1:
            errors.append(f"Required item appears more than once: {required_item}")

    if FINAL_ROOM in rooms and rooms[FINAL_ROOM].get("encounter") != FINAL_ENCOUNTER:
        errors.append(f"{FINAL_ROOM} must contain the {FINAL_ENCOUNTER} encounter.")

    if STARTING_ROOM in rooms:
        reachable = reachable_rooms(rooms, STARTING_ROOM)
        unreachable = sorted(set(rooms).difference(reachable))
        if unreachable:
            errors.append("Unreachable rooms: " + ", ".join(unreachable))

    if errors:
        raise ValueError("Invalid world map:\n- " + "\n- ".join(errors))


@dataclass
class Player:
    """Track Link's location and unique collection of items."""

    current_room: str = STARTING_ROOM
    inventory: Set[str] = field(default_factory=set)

    def has_all_required_items(self) -> bool:
        """Return True when every required item has been collected."""
        return REQUIRED_ITEMS.issubset(self.inventory)

    def missing_items(self) -> Set[str]:
        """Return the required items that are not yet in the inventory."""
        return set(REQUIRED_ITEMS.difference(self.inventory))


class Game:
    """Manage the game world, commands, graph search, and session state."""

    def __init__(self) -> None:
        self.rooms = build_world()
        validate_world(self.rooms)
        self.player = Player()
        self.is_running = True

    def show_intro(self) -> None:
        """Display the opening story and supported commands."""
        print("Link wakes up from his bed in Kokiri Forest.")
        print('On his table he sees "HELP!" with a picture of Zelda being held by Ganon.')
        print("Save Zelda, Link!")
        print()
        print("Commands:")
        print("  go <direction>     Example: go north")
        print("  north/south/east/west")
        print("  pick up <item>     Example: pick up Master Sword")
        print("  take <item>        Example: take Hammer")
        print("  inventory")
        print("  hint")
        print("  help")
        print("  exit")
        print()

    def ordered_inventory(self) -> list[str]:
        """Return collected items in a consistent story-based order."""
        return [item for item in REQUIRED_ITEM_ORDER if item in self.player.inventory]

    def display_status(self) -> None:
        """Display Link's current location, inventory, and room details."""
        room = self.rooms[self.player.current_room]
        available_directions = [
            direction.title() for direction in DIRECTION_ORDER if direction in room
        ]

        print("-----------------")
        print(f"Current Room: {self.player.current_room}")
        print("Available Directions:", ", ".join(available_directions) or "None")

        item = room.get("item")
        if item:
            print(f"Item: {item}")
        else:
            print("There appears to be no item here.")

        inventory = self.ordered_inventory()
        print("Inventory:", ", ".join(inventory) if inventory else "Empty")
        print("-----------------")

    @staticmethod
    def normalize_command(raw_command: str) -> str:
        """Trim repeated whitespace while preserving item capitalization."""
        return " ".join(raw_command.strip().split())

    @staticmethod
    def parse_command(command: str) -> Tuple[str, Optional[str]]:
        """Convert user input into an action and optional argument."""
        lowered = command.lower()

        if lowered in DIRECTIONS:
            return "move", lowered
        if lowered.startswith("go "):
            return "move", lowered[3:].strip()
        if lowered.startswith("pick up "):
            return "pickup", command[8:].strip()
        if lowered.startswith("take "):
            return "pickup", command[5:].strip()
        if lowered in {"inventory", "inv"}:
            return "inventory", None
        if lowered in {"hint", "clue"}:
            return "hint", None
        if lowered in {"help", "commands"}:
            return "help", None
        if lowered in {"exit", "quit"}:
            return "exit", None

        return "invalid", None

    def move_player(self, direction: str) -> None:
        """Move Link when the requested edge exists in the room graph."""
        if direction not in DIRECTIONS:
            print("That is not a valid direction.")
            return

        destination = self.rooms[self.player.current_room].get(direction)
        if destination is None:
            print("An invisible wall blocks your way. Try another direction.")
            return

        self.player.current_room = destination
        self.handle_room_event()

    def pick_up_item(self, requested_item: str) -> None:
        """Collect a room item when the requested name matches."""
        if not requested_item:
            print("Tell me which item you want to pick up.")
            return

        room = self.rooms[self.player.current_room]
        room_item = room.get("item")

        if room_item is None:
            print("There is no item here to pick up.")
            return
        if requested_item.casefold() != room_item.casefold():
            print(f"There is no {requested_item} here to pick up.")
            return

        # A set guarantees that the same item cannot be stored twice.
        self.player.inventory.add(room_item)
        del room["item"]
        print(f"{room_item} has been added to your inventory.")

        if self.player.has_all_required_items():
            print("You are now ready to face Ganon! Head to the top of Hyrule Castle.")

    def find_shortest_path(
        self, start_room: str, target_rooms: Iterable[str]
    ) -> Optional[Tuple[list[str], str]]:
        """Find the shortest path from start_room to any target using BFS.

        Returns a tuple containing the movement directions and the destination
        room. None is returned when no target can be reached.
        """
        targets = set(target_rooms)
        if start_room not in self.rooms or not targets:
            return None
        if start_room in targets:
            return [], start_room

        queue = deque([start_room])
        visited = {start_room}
        predecessor: Dict[str, Optional[str]] = {start_room: None}
        direction_used: Dict[str, str] = {}
        found_target: Optional[str] = None

        while queue:
            current_room = queue.popleft()

            for direction in DIRECTION_ORDER:
                destination = self.rooms[current_room].get(direction)
                if destination is None or destination in visited:
                    continue

                visited.add(destination)
                predecessor[destination] = current_room
                direction_used[destination] = direction

                if destination in targets:
                    found_target = destination
                    queue.clear()
                    break

                queue.append(destination)

        if found_target is None:
            return None

        reversed_directions = []
        room_name = found_target
        previous_room = predecessor[room_name]

        while previous_room is not None:
            reversed_directions.append(direction_used[room_name])
            room_name = previous_room
            previous_room = predecessor[room_name]

        reversed_directions.reverse()
        return reversed_directions, found_target

    def get_hint(self) -> str:
        """Return the next shortest move toward a missing item or Ganon."""
        current_room = self.player.current_room
        missing_items = self.player.missing_items()

        if missing_items:
            room_item = self.rooms[current_room].get("item")
            if room_item in missing_items:
                return f"Hint: Pick up the {room_item} in this room."

            item_rooms = {
                room_name: room["item"]
                for room_name, room in self.rooms.items()
                if room.get("item") in missing_items
            }
            result = self.find_shortest_path(current_room, item_rooms)
            if result is None:
                return "Hint: No reachable room contains one of the missing items."

            directions, target_room = result
            if not directions:
                return f"Hint: Pick up the {item_rooms[target_room]} in this room."

            item_name = item_rooms[target_room]
            room_count = len(directions)
            room_word = "room" if room_count == 1 else "rooms"
            return (
                f"Hint: Go {directions[0]} toward the {item_name}. "
                f"It is {room_count} {room_word} away."
            )

        result = self.find_shortest_path(current_room, {FINAL_ROOM})
        if result is None:
            return "Hint: Ganon cannot be reached from your current location."

        directions, _ = result
        if not directions:
            return "Hint: You have reached Ganon. Prepare for the final battle."

        room_count = len(directions)
        room_word = "room" if room_count == 1 else "rooms"
        return (
            f"Hint: Go {directions[0]} toward Ganon at the top of Hyrule Castle. "
            f"He is {room_count} {room_word} away."
        )

    def provide_hint(self) -> None:
        """Display an algorithm-generated hint to the player."""
        print(self.get_hint())

    def handle_room_event(self) -> None:
        """Handle special room events after movement."""
        room = self.rooms[self.player.current_room]

        if room.get("event") == "cucco":
            print("A single Cucco stands before you, menacingly...")
            print("There is nowhere else to go but back where you came from.")

        if room.get("encounter") == FINAL_ENCOUNTER:
            self.resolve_final_encounter()

    def resolve_final_encounter(self) -> None:
        """End the session with the appropriate Ganon result."""
        if self.player.has_all_required_items():
            print()
            print("You have everything you need. Ganon appears before you at the top of Hyrule Castle.")
            print("After an intense fight, Link defeats Ganon.")
            print("Link has saved Zelda and the land of Hyrule.")
        else:
            missing_count = len(self.player.missing_items())
            print()
            print("You enter the top of Hyrule Castle and feel a sinister force.")
            print(f"You are still missing {missing_count} required item(s).")
            print("Before you can escape, Ganon strikes. It appears this is the end of our hero.")

        self.is_running = False

    def show_help(self) -> None:
        """Display the accepted command formats."""
        print("Use 'go north' or simply 'north' to move.")
        print("Use 'pick up <item>' or 'take <item>' to collect an item.")
        print("Use 'inventory' to review collected items.")
        print("Use 'hint' for the next shortest move toward a missing item or Ganon.")
        print("Use 'exit' to leave the game.")

    def confirm_exit(self) -> bool:
        """Return True only when the player confirms leaving the game."""
        while True:
            response = input("Would you like to leave? (yes or no): ").strip().lower()
            if response in {"yes", "y"}:
                return True
            if response in {"no", "n"}:
                return False
            print("Please enter yes or no.")

    def process_command(self, raw_command: str) -> None:
        """Route a command to the appropriate gameplay method."""
        command = self.normalize_command(raw_command)
        action, argument = self.parse_command(command)

        if action == "move" and argument is not None:
            self.move_player(argument)
        elif action == "pickup" and argument is not None:
            self.pick_up_item(argument)
        elif action == "inventory":
            inventory = self.ordered_inventory()
            print("Inventory:", ", ".join(inventory) if inventory else "Empty")
        elif action == "hint":
            self.provide_hint()
        elif action == "help":
            self.show_help()
        elif action == "exit":
            if self.confirm_exit():
                print("You have exited the game.")
                self.is_running = False
        else:
            print("Invalid command. Type 'help' to see the available commands.")

    def run(self) -> None:
        """Run one complete game session."""
        self.show_intro()

        while self.is_running:
            self.display_status()
            command = input("Enter a command: ")
            self.process_command(command)


def ask_to_play_again() -> bool:
    """Return True when the player wants to start a new session."""
    while True:
        response = input("Would you like to play again? (yes or no): ").strip().lower()
        if response in {"yes", "y"}:
            return True
        if response in {"no", "n"}:
            return False
        print("Please enter yes or no.")


def main() -> None:
    """Run game sessions without recursive restarts."""
    while True:
        game = Game()
        game.run()

        if not ask_to_play_again():
            print("Thank you for playing.")
            break


if __name__ == "__main__":
    main()
